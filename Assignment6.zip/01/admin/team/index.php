<?php
$teamFile = '../../data/team.CSV';
$teamMembers = [];
if (file_exists($teamFile)) {
    if (($handle = fopen($teamFile, 'r')) !== false) {
        while (($data = fgetcsv($handle, 1000, ",")) !== false) {
            $teamMembers[] = [
                'name' => $data[0],
                'position' => $data[1],
                'description' => $data[2]
            ];
        }
        fclose($handle);
    }
} else {
    echo "<p>No team members found. Please add one.</p>";
}
echo "<h1>Manage Team Members</h1>";
echo "<table border='1' cellpadding='10'>";
echo "<tr><th>Name</th><th>Position</th><th>Actions</th></tr>";
if (!empty($teamMembers)) {
    foreach ($teamMembers as $index => $member) {
        echo "<tr>";
        echo "<td>{$member['name']}</td>";
        echo "<td>{$member['position']}</td>";
        echo "<td>
                <a href='details.php?id={$index}'>View</a> |
                <a href='edit.php?id={$index}'>Edit</a> |
                <a href='delete.php?id={$index}'>Delete</a>
              </td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='3'>No team members available.</td></tr>";
}
echo "</table>";
echo "<p><a href='create.php'>Create New Team Member</a></p>";
?>
