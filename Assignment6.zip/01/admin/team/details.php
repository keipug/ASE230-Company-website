<?php
$teamFile = '../../data/team.CSV';
$id = isset($_GET['id']) ? (int)$_GET['id'] : -1;
$teamMember = null;
if (($handle = fopen($teamFile, 'r')) !== false) {
    $index = 0;
    while (($data = fgetcsv($handle, 1000, ",")) !== false) {
        if ($index === $id) {
            $teamMember = [
                'name' => $data[0],
                'position' => $data[1],
                'description' => $data[2]
            ];
            break;
        }
        $index++;
    }
    fclose($handle);
}
if ($teamMember) {
    echo "<h1>Team Member Details</h1>";
    echo "<p><strong>Name:</strong> {$teamMember['name']}</p>";
    echo "<p><strong>Position:</strong> {$teamMember['position']}</p>";
    echo "<p><strong>Description:</strong> {$teamMember['description']}</p>";
    echo "<p><a href='edit.php?id={$id}'>Edit</a> | <a href='delete.php?id={$id}'>Delete</a> | <a href='index.php'>Back to List</a></p>";
} else {
    echo "<p>Team member not found. <a href='index.php'>Back to List</a></p>";
}
?>
