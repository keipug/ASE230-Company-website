<?php
$teamFile = '../../data/team.csv';
$id = isset($_GET['id']) ? (int)$_GET['id'] : -1;
$teamMembers = [];
$teamMember = null;
if (($handle = fopen($teamFile, 'r')) !== false) {
    while (($data = fgetcsv($handle, 1000, ",")) !== false) {
        $teamMembers[] = $data;
    }
    fclose($handle);
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $teamMembers[$id][0] = $_POST['name'];
    $teamMembers[$id][1] = $_POST['position'];
    $teamMembers[$id][2] = $_POST['description'];
    if (($handle = fopen($teamFile, 'w')) !== false) {
        foreach ($teamMembers as $member) {
            fputcsv($handle, $member);
        }
        fclose($handle);
    }
    header('Location: index.php');
    exit;
}
if (isset($teamMembers[$id])) {
    $teamMember = $teamMembers[$id];
    ?>
    <h1>Edit Team Member</h1>
    <form method="POST" action="">
        <p>
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($teamMember[0]); ?>" required>
        </p>
        <p>
            <label for="position">Position:</label>
            <input type="text" id="position" name="position" value="<?php echo htmlspecialchars($teamMember[1]); ?>" required>
        </p>
        <p>
            <label for="description">Description:</label>
            <textarea id="description" name="description" required><?php echo htmlspecialchars($teamMember[2]); ?></textarea>
        </p>
        <p>
            <button type="submit">Save Changes</button>
        </p>
    </form>
    <p><a href="detail.php?id=<?php echo $id; ?>">Cancel</a></p>
    <?php
} else {
    echo "<p>Team member not found. <a href='index.php'>Back to List</a></p>";
}
?>
