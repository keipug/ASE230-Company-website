<?php
$teamFile = '../../data/team.csv';
$id = isset($_GET['id']) ? (int)$_GET['id'] : -1;
$teamMembers = [];
if (($handle = fopen($teamFile, 'r')) !== false) {
    while (($data = fgetcsv($handle, 1000, ",")) !== false) {
        $teamMembers[] = $data;
    }
    fclose($handle);
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    unset($teamMembers[$id]);
    $teamMembers = array_values($teamMembers);
    if (($handle = fopen($teamFile, 'w')) !== false) {
        foreach ($teamMembers as $member) {
            fputcsv($handle, $member);
        }
        fclose($handle);
    }
    header('Location: index.php');
    exit;
}
if (isset($teamMembers[$id])) {
    ?>
    <h1>Delete Team Member</h1>
    <p>Are you sure you want to delete <strong><?php echo htmlspecialchars($teamMembers[$id][0]); ?></strong>?</p>
    <form method="POST" action="">
        <button type="submit">Yes, Delete</button>
        <a href="detail.php?id=<?php echo $id; ?>">Cancel</a>
    </form>
    <?php
} else {
    echo "<p>Team member not found. <a href='index.php'>Back to List</a></p>";
}
?>
