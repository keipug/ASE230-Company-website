<?php
$teamFile = '../../data/team.CSV';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $position = $_POST['position'];
    $description = $_POST['description'];
    if (($handle = fopen($teamFile, 'a')) !== false) {
        fputcsv($handle, [$name, $position, $description]);
        fclose($handle);
    }
    header('Location: index.php');
    exit;
}
?>
<h1>Create New Team Member</h1>
<form method="POST" action="">
    <p>
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>
    </p>
    <p>
        <label for="position">Position:</label>
        <input type="text" id="position" name="position" required>
    </p>
    <p>
        <label for="description">Description:</label>
        <textarea id="description" name="description" required></textarea>
    </p>
    <p>
        <button type="submit">Create Team Member</button>
    </p>
</form>
<p><a href="index.php">Back to List</a></p>
