<?php
$jsonFile = '../../data/pages.json';
$index = isset($_GET['index']) ? (int)$_GET['index'] : -1;
$pages = json_decode(file_get_contents($jsonFile), true)['pages'];
if ($index < 0 || $index >= count($pages)) {
    die('Page not found.');
}
$page = $pages[$index];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Page Details</title>
</head>
<body>
    <h1>Page: <?php echo htmlspecialchars($page['page']); ?></h1>
    <p><strong>Title:</strong> <?php echo htmlspecialchars($page['title']); ?></p>
    <p><strong>Mission:</strong> <?php echo htmlspecialchars($page['mission']); ?></p>
    <p><strong>Overview:</strong> <?php echo htmlspecialchars($page['overview']); ?></p>
    <br>
    <a href="index.php">Back to Pages</a>
</body>
</html>
