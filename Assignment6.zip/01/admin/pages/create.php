<?php
$jsonFile = '../../data/pages.json';
$title = $mission = $overview = $pageFile = "";
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pageFile = $_POST['page'];
    $title = $_POST['title'];
    $mission = $_POST['mission'];
    $overview = $_POST['overview'];
    if (empty($pageFile) || empty($title) || empty($mission) || empty($overview)) {
        $errors[] = 'All fields are required.';
    } else {
        $pages = json_decode(file_get_contents($jsonFile), true);
        $pages['pages'][] = [
            'page' => $pageFile,
            'title' => $title,
            'mission' => $mission,
            'overview' => $overview
        ];
        file_put_contents($jsonFile, json_encode($pages, JSON_PRETTY_PRINT));
        header('Location: index.php');
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create New Page</title>
</head>
<body>
    <h1>Create New Page</h1>

    <?php if (!empty($errors)): ?>
        <ul>
            <?php foreach ($errors as $error): ?>
                <li><?php echo htmlspecialchars($error); ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
    <form method="POST">
        <label>Page File:</label>
        <input type="text" name="page" value="<?php echo htmlspecialchars($pageFile); ?>"><br><br>
        <label>Title:</label>
        <input type="text" name="title" value="<?php echo htmlspecialchars($title); ?>"><br><br>
        <label>Mission:</label>
        <textarea name="mission"><?php echo htmlspecialchars($mission); ?></textarea><br><br>
        <label>Overview:</label>
        <textarea name="overview"><?php echo htmlspecialchars($overview); ?></textarea><br><br>
        <input type="submit" value="Create">
    </form>
    <br>
    <a href="index.php">Cancel</a>
</body>
</html>
