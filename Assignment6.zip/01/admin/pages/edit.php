<?php
$jsonFile = '../../data/pages.json';
$index = isset($_GET['index']) ? (int)$_GET['index'] : -1;
$pages = json_decode(file_get_contents($jsonFile), true);
if ($index < 0 || $index >= count($pages['pages'])) {
    die('Page not found.');
}
$page = $pages['pages'][$index];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pages['pages'][$index] = [
        'page' => $_POST['page'],
        'title' => $_POST['title'],
        'mission' => $_POST['mission'],
        'overview' => $_POST['overview']
    ];
    file_put_contents($jsonFile, json_encode($pages, JSON_PRETTY_PRINT));
    header('Location: index.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Page</title>
</head>
<body>
    <h1>Edit Page</h1>
    <form method="POST">
        <label>Page File:</label>
        <input type="text" name="page" value="<?php echo htmlspecialchars($page['page']); ?>"><br><br>
        <label>Title:</label>
        <input type="text" name="title" value="<?php echo htmlspecialchars($page['title']); ?>"><br><br>
        <label>Mission:</label>
        <textarea name="mission"><?php echo htmlspecialchars($page['mission']); ?></textarea><br><br>
        <label>Overview:</label>
        <textarea name="overview"><?php echo htmlspecialchars($page['overview']); ?></textarea><br><br>
        <input type="submit" value="Update">
    </form>
    <br>
    <a href="index.php">Cancel</a>
</body>
</html>
