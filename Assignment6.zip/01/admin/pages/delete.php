<?php
$jsonFile = '../../data/pages.json';
$index = isset($_GET['index']) ? (int)$_GET['index'] : -1;
$pages = json_decode(file_get_contents($jsonFile), true);
if ($index < 0 || $index >= count($pages['pages'])) {
    die('Page not found.');
}
$pageToDelete = $pages['pages'][$index];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    unset($pages['pages'][$index]);
    $pages['pages'] = array_values($pages['pages']);
    file_put_contents($jsonFile, json_encode($pages, JSON_PRETTY_PRINT));
    header('Location: index.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delete Page</title>
</head>
<body>
    <h1>Delete Page</h1>
    <p>Are you sure you want to delete the page "<?php echo htmlspecialchars($pageToDelete['page']); ?>"?</p>
    <form method="POST">
        <input type="submit" value="Delete">
    </form>
    <br>
    <a href="index.php">Cancel</a>
</body>
</html>
