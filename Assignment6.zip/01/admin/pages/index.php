<?php
$jsonFile = '../../data/pages.json';
$pages = json_decode(file_get_contents($jsonFile), true)['pages'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Pages</title>
</head>
<body>
    <h1>All Pages</h1>
    <table border="1">
        <thead>
            <tr>
                <th>Page</th>
                <th>Title</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($pages as $index => $page): ?>
                <tr>
                    <td><?php echo htmlspecialchars($page['page']); ?></td>
                    <td><?php echo htmlspecialchars($page['title']); ?></td>
                    <td>
                        <a href="details.php?index=<?php echo $index; ?>">View</a> |
                        <a href="edit.php?index=<?php echo $index; ?>">Edit</a> |
                        <a href="delete.php?index=<?php echo $index; ?>">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <br>
    <a href="create.php">Create New Page</a>
</body>
</html>
