<?php
$csvFile = '../../data/contacts.csv';
$index = isset($_GET['index']) ? (int)$_GET['index'] : -1;
$contacts = [];
if (($handle = fopen($csvFile, 'r')) !== FALSE) {
    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
        $contacts[] = $data;
    }
    fclose($handle);
}
if ($index < 0 || $index >= count($contacts)) {
    die('Contact request not found.');
}
$contact = $contacts[$index];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Contact Request Details</title>
</head>
<body>
    <h1>Contact Request Details</h1>
    <p><strong>Name:</strong> <?php echo htmlspecialchars($contact[0]); ?></p>
    <p><strong>Email:</strong> <?php echo htmlspecialchars($contact[1]); ?></p>
    <p><strong>Subject:</strong> <?php echo htmlspecialchars($contact[2]); ?></p>
    <p><strong>Message:</strong> <?php echo htmlspecialchars($contact[3]); ?></p>
    <br>
    <a href="index.php">Back to Contacts List</a>
</body>
</html>
