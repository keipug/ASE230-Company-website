<?php
$csvFile = '../../data/contacts.csv';
$contacts = [];
if (($handle = fopen($csvFile, 'r')) !== FALSE) {
    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
        $contacts[] = $data;
    }
    fclose($handle);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Contacts List</title>
</head>
<body>
    <h1>Contact Requests</h1>
    <table border="1">
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Subject</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($contacts as $index => $contact): ?>
            <tr>
                <td><?php echo htmlspecialchars($contact[0]); ?></td>
                <td><?php echo htmlspecialchars($contact[1]); ?></td>
                <td><?php echo htmlspecialchars($contact[2]); ?></td>
                <td>
                    <a href="detail.php?index=<?php echo $index; ?>">Details</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
    <br>
    <a href="../index.php">Back to Homepage</a>
</body>
</html>
