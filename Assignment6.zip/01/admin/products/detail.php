<?php
$jsonFile = '../../data/products.json';
$index = isset($_GET['index']) ? (int)$_GET['index'] : -1;
$products = json_decode(file_get_contents($jsonFile), true);
if ($index < 0 || $index >= count($products)) {
    die('Product not found.');
}
$product = $products[$index];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Product Details</title>
</head>
<body>
    <h1>Product Details: <?php echo htmlspecialchars($product['name']); ?></h1>
    <p><strong>Description:</strong> <?php echo htmlspecialchars($product['description']); ?></p>
    <h3>Applications:</h3>
    <ul>
        <?php foreach ($product['applications'] as $application): ?>
            <li><?php echo htmlspecialchars($application['name']); ?>: <?php echo htmlspecialchars($application['description']); ?></li>
        <?php endforeach; ?>
    </ul>
    <br>
    <a href="index.php">Back to Products List</a>
</body>
</html>
