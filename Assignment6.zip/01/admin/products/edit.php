<?php
$jsonFile = '../../data/products.json';
$index = isset($_GET['index']) ? (int)$_GET['index'] : -1;
$products = json_decode(file_get_contents($jsonFile), true);
if ($index < 0 || $index >= count($products)) {
    die('Product not found.');
}
$product = $products[$index];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $products[$index]['name'] = $_POST['name'];
    $products[$index]['description'] = $_POST['description'];
    $products[$index]['applications'] = [];
    for ($i = 0; $i < count($_POST['app_name']); $i++) {
        $products[$index]['applications'][] = [
            'name' => $_POST['app_name'][$i],
            'description' => $_POST['app_description'][$i]
        ];
    }
    file_put_contents($jsonFile, json_encode($products, JSON_PRETTY_PRINT));
    header('Location: index.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Product</title>
</head>
<body>
    <h1>Edit Product: <?php echo htmlspecialchars($product['name']); ?></h1>

    <form method="POST">
        <label for="name">Product Name:</label>
        <input type="text" name="name" value="<?php echo htmlspecialchars($product['name']); ?>" required><br><br>
        <label for="description">Description:</label>
        <textarea name="description" required><?php echo htmlspecialchars($product['description']); ?></textarea><br><br>
        <h3>Applications:</h3>
        <div id="applications">
            <?php foreach ($product['applications'] as $app): ?>
                <label for="app_name[]">Application Name:</label>
                <input type="text" name="app_name[]" value="<?php echo htmlspecialchars($app['name']); ?>" required><br><br>
                <label for="app_description[]">Application Description:</label>
                <textarea name="app_description[]" required><?php echo htmlspecialchars($app['description']); ?></textarea><br><br>
            <?php endforeach; ?>
        </div>
        <button type="button" onclick="addApplication()">Add Another Application</button><br><br>
        <input type="submit" value="Save Changes">
    </form>
    <br>
    <a href="index.php">Cancel</a>
    <script>
        function addApplication() {
            const appDiv = document.createElement('div');
            appDiv.innerHTML = `
                <label for="app_name[]">Application Name:</label>
                <input type="text" name="app_name[]" required><br><br>
                <label for="app_description[]">Application Description:</label>
                <textarea name="app_description[]" required></textarea><br><br>
            `;
            document.getElementById('applications').appendChild(appDiv);
        }
    </script>
</body>
</html>
