<?php
$jsonFile = '../../data/products.json';
$products = json_decode(file_get_contents($jsonFile), true);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Products List</title>
</head>
<body>
    <h1>Products</h1>
    <table border="1">
        <tr>
            <th>Product Name</th>
            <th>Description</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($products as $index => $product): ?>
            <tr>
                <td><?php echo htmlspecialchars($product['name']); ?></td>
                <td><?php echo htmlspecialchars($product['description']); ?></td>
                <td>
                    <a href="detail.php?index=<?php echo $index; ?>">Details</a> |
                    <a href="edit.php?index=<?php echo $index; ?>">Edit</a> |
                    <a href="delete.php?index=<?php echo $index; ?>">Delete</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
    <br>
    <a href="create.php">Create New Product</a>
</body>
</html>
