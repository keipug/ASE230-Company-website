<?php
$jsonFile = '../../data/products.json';
$products = json_decode(file_get_contents($jsonFile), true);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newProduct = [
        'name' => $_POST['name'],
        'description' => $_POST['description'],
        'applications' => []
    ];
    for ($i = 0; $i < count($_POST['app_name']); $i++) {
        $newProduct['applications'][] = [
            'name' => $_POST['app_name'][$i],
            'description' => $_POST['app_description'][$i]
        ];
    }
    $products[] = $newProduct;
    file_put_contents($jsonFile, json_encode($products, JSON_PRETTY_PRINT));
    header('Location: index.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create New Product</title>
</head>
<body>
    <h1>Create New Product</h1>
    <form method="POST">
        <label for="name">Product Name:</label>
        <input type="text" name="name" required><br><br>
        <label for="description">Description:</label>
        <textarea name="description" required></textarea><br><br>
        <h3>Applications:</h3>
        <div id="applications">
            <label for="app_name[]">Application Name:</label>
            <input type="text" name="app_name[]" required><br><br>
            <label for="app_description[]">Application Description:</label>
            <textarea name="app_description[]" required></textarea><br><br>
        </div>
        <button type="button" onclick="addApplication()">Add Another Application</button><br><br>
        <input type="submit" value="Create Product">
    </form>
    <br>
    <a href="index.php">Cancel</a>
    <script>
        function addApplication() {
            const appDiv = document.createElement('div');
            appDiv.innerHTML = `
                <label for="app_name[]">Application Name:</label>
                <input type="text" name="app_name[]" required><br><br>
                <label for="app_description[]">Application Description:</label>
                <textarea name="app_description[]" required></textarea><br><br>
            `;
            document.getElementById('applications').appendChild(appDiv);
        }
    </script>
</body>
</html>
