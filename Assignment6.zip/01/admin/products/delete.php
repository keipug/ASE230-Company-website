<?php
$jsonFile = '../../data/products.json';
$index = isset($_GET['index']) ? (int)$_GET['index'] : -1;
$products = json_decode(file_get_contents($jsonFile), true);
if ($index < 0 || $index >= count($products)) {
    die('Product not found.');
}
$productToDelete = $products[$index];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    unset($products[$index]);
    $products = array_values($products);
    file_put_contents($jsonFile, json_encode($products, JSON_PRETTY_PRINT));
    header('Location: index.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delete Product</title>
</head>
<body>
    <h1>Delete Product</h1>
    <p>Are you sure you want to delete the product "<?php echo htmlspecialchars($productToDelete['name']); ?>"?</p>
    <form method="POST">
        <input type="hidden" name="confirm" value="yes">
        <input type="submit" value="Yes, Delete">
    </form>
    <br>
    <a href="index.php">Cancel</a>
</body>
</html>
