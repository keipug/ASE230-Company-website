<?php
$csvFile = '../../data/awards.CSV';
$index = isset($_GET['index']) ? (int)$_GET['index'] : -1;
$awards = [];
if (($handle = fopen($csvFile, 'r')) !== FALSE) {
    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
        $awards[] = $data;
    }
    fclose($handle);
}
if ($index < 0 || $index >= count($awards)) {
    die('Award not found.');
}
$awardToDelete = $awards[$index];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['confirm']) && $_POST['confirm'] === 'yes') {
        unset($awards[$index]);
        $awards = array_values($awards);
        if (($handle = fopen($csvFile, 'w')) !== FALSE) {
            foreach ($awards as $award) {
                fputcsv($handle, $award);
            }
            fclose($handle);
            header('Location: index.php');
            exit();
        } else {
            $error = "Error updating file.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delete Award</title>
</head>
<body>
    <h1>Delete Award</h1>
    <p>Are you sure you want to delete the award "<?php echo htmlspecialchars($awardToDelete[1]); ?>" from the year <?php echo htmlspecialchars($awardToDelete[0]); ?>?</p>
    <form method="POST" action="">
        <input type="hidden" name="index" value="<?php echo $index; ?>">
        <input type="hidden" name="confirm" value="yes">
        <input type="submit" value="Yes, Delete">
    </form>
    <br>
    <a href="index.php">Cancel</a>
</body>
</html>
