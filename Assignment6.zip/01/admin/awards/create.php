<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $year = $_POST['year'];
    $award = $_POST['award'];
    $newAward = [$year, $award];
    $csvFile = '../../data/awards.CSV';
    if (($handle = fopen($csvFile, 'a')) !== FALSE) {
        fputcsv($handle, $newAward);
        fclose($handle);
        header('Location: index.php');
        exit();
    } else {
        $error = "Unable to write to file.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create New Award</title>
</head>
<body>
    <h1>Create New Award</h1>
    <?php if (isset($error)): ?>
    <p style="color: red;"><?php echo $error; ?></p>
    <?php endif; ?>
    <form method="POST" action="">
        <label for="year">Year:</label>
        <input type="text" name="year" id="year" required><br><br>
        <label for="award">Award:</label>
        <input type="text" name="award" id="award" required><br><br>
        <input type="submit" value="Create">
    </form>
    <br>
    <a href="index.php">Back to Awards List</a>
</body>
</html>
