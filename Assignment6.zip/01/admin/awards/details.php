<?php
$csvFile = '../../data/awards.CSV';
$index = isset($_GET['index']) ? (int)$_GET['index'] : -1;
$award = null;
if (($handle = fopen($csvFile, 'r')) !== FALSE) {
    $i = 0;
    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
        if ($i === $index) {
            $award = $data;
            break;
        }
        $i++;
    }
    fclose($handle);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Award Details</title>
</head>
<body>
    <h1>Award Details</h1>
    <?php if ($award): ?>
    <p><strong>Year:</strong> <?php echo htmlspecialchars($award[0]); ?></p>
    <p><strong>Award:</strong> <?php echo htmlspecialchars($award[1]); ?></p>
    <br>
    <a href="index.php">Back to Awards List</a>
    <?php else: ?>
    <p>Award not found.</p>
    <?php endif; ?>
</body>
</html>
