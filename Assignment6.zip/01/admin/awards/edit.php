<?php
$csvFile = '../../data/awards.CSV';
$index = isset($_GET['index']) ? (int)$_GET['index'] : -1;
$awards = [];
$selectedAward = null;
if (($handle = fopen($csvFile, 'r')) !== FALSE) {
    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
        $awards[] = $data;
    }
    fclose($handle);
}
if ($index >= 0 && $index < count($awards)) {
    $selectedAward = $awards[$index];
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $awards[$index][0] = $_POST['year'];
    $awards[$index][1] = $_POST['award'];
    // Overwrite the CSV file with updated data
    if (($handle = fopen($csvFile, 'w')) !== FALSE) {
        foreach ($awards as $award) {
            fputcsv($handle, $award);
        }
        fclose($handle);
        header('Location: index.php');
        exit();
    } else {
        $error = "Unable to update file.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Award</title>
</head>
<body>
    <h1>Edit Award</h1>
    <?php if ($selectedAward): ?>
    <form method="POST" action="">
        <label for="year">Year:</label>
        <input type="text" name="year" id="year" value="<?php echo htmlspecialchars($selectedAward[0]); ?>" required><br><br>
        <label for="award">Award:</label>
        <input type="text" name="award" id="award" value="<?php echo htmlspecialchars($selectedAward[1]); ?>" required><br><br>
        <input type="submit" value="Save Changes">
    </form>
    <?php else: ?>
    <p>Award not found.</p>
    <?php endif; ?>
    <br>
    <a href="index.php">Back to Awards List</a>
</body>
</html>
