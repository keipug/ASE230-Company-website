<?php
$csvFile = '../../data/awards.CSV';
$awards = [];
if (($handle = fopen($csvFile, 'r')) !== FALSE) {
    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
        $awards[] = $data;
    }
    fclose($handle);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Awards List</title>
</head>
<body>
    <h1>Awards List</h1>
    <table border="1">
        <tr>
            <th>Year</th>
            <th>Award</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($awards as $index => $award): ?>
        <tr>
            <td><?php echo htmlspecialchars($award[0]); ?></td>
            <td><?php echo htmlspecialchars($award[1]); ?></td>
            <td>
                <a href="details.php?index=<?php echo $index; ?>">View</a> | 
                <a href="edit.php?index=<?php echo $index; ?>">Edit</a> | 
                <a href="delete.php?index=<?php echo $index; ?>">Delete</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
    <br>
    <a href="create.php">Create New Award</a>
</body>
</html>
