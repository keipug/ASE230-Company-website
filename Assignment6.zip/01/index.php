<?php
function readTextFile($file) {
    return file_get_contents($file);
}
function readCSVFile($file) {
    $rows = array_map('str_getcsv', file($file));
    $header = array_shift($rows);
    $csv = [];
    foreach ($rows as $row) {
        $csv[] = array_combine($header, $row);
    }
    return $csv;
}
function readJSONFile($file) {
    $json = file_get_contents($file);
    return json_decode($json, true);
}
$team = readCSVFile('data/team.csv');
$awards = readCSVFile('data/awards.csv');
$products = readJSONFile('data/products.json');
$pages = readJSONFile('data/pages.json');
$pageData = $pages['pages'][0];
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>Qexal - Responsive Bootstrap 5 Landing Page Template</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta name="description" content="Premium Bootstrap 5 Landing Page Template" />
        <meta name="keywords" content="bootstrap 5, premium, marketing, multipurpose" />
        <meta content="Themesbrand" name="author" />
        <!-- favicon -->
        <link rel="shortcut icon" href="images/favicon.ico" />

        <!-- css -->
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="css/materialdesignicons.min.css" rel="stylesheet" type="text/css" />
        <link href="css/style.min.css" rel="stylesheet" type="text/css" />
    </head>

    <body data-bs-spy="scroll" data-bs-target="#navbar" data-bs-offset="20">
        <!-- Loader -->
        <div id="preloader">
            <div id="status">
                <div class="spinner">
                    <div class="bounce1"></div>
                    <div class="bounce2"></div>
                    <div class="bounce3"></div>
                  </div>
            </div>
        </div>

        <!--Navbar Start-->
        <nav class="navbar navbar-expand-lg navbar-light navbar-custom fixed-top" id="navbar">
            <div class="container">
                <!-- LOGO -->
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="navbar-nav ms-auto navbar-center" id="navbar-navlist">
                        <li class="nav-item">
                            <a href="#home" class="nav-link active"><?php echo "Home" ?></a>
                        </li>
                        <li class="nav-item">
                            <a href="#services" class="nav-link"><?php echo "Overview" ?></a>
                        </li>
                        <li class="nav-item">
                            <a href="#pricing" class="nav-link"><?php echo "Awards" ?></a>
                        </li>
                        <li class="nav-item">
                            <a href="#team" class="nav-link"><?php echo "Team" ?></a>
                        </li>
                        <li class="nav-item">
                            <a href="#blog" class="nav-link"><?php echo "Products" ?></a>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- end container -->
        </nav>
        <!-- Navbar End -->

        <!-- Hero Start -->
        <section class="hero-3 bg-center position-relative" style="background-image: url(images/hero-3-bg.png);" id="home">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-8">
                        <div class="text-center">
                            <h1 class="font-weight-semibold mb-4 hero-3-title"><?php echo "Orion Aerospace Dynamics" ?></h1>
                            <p class="mb-5 text-muted subtitle w-75 mx-auto"><?php echo $pageData['mission'] ?></p>
                        </div>
                    </div><!-- end col -->
                </div><!-- end row -->
            </div>
        </section>
        <!-- Hero End -->

        <!-- Services start -->
        <section class="section" id="services">
            <div class="container">
                <div class="row justify-content-center mb-5">
                    <div class="col-lg-7 text-center">
                        <h2 class="fw-bold"><?php echo "Overview" ?></h2>
                        <p class="text-muted"><?php echo $pageData['overview'] ?></p>
                    </div>
                </div>
                <!-- end row -->
                
        </section>
        <!-- Services end -->
        <!-- Pricing start -->
        <section class="section" id="pricing">
            <div class="container">
                <div class="row justify-content-center mb-5">
                    <div class="col-lg-7 text-center">
                        <h2 class="fw-bold"><?php echo "Awards" ?></h2>
                    </div>
                </div>
                <!-- end row -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="tab-content" id="pricingpills-tabContent">
                            <div class="tab-pane fade show active" id="pills-monthly" role="tabpanel" aria-labelledby="pills-monthly-tab">
                                <div class="row">
                                    <?php foreach ($awards as $award): ?>
                                    <div class="col-lg-4">
                                        <div class="card plan-card mt-4 rounded text-center border-0 shadow overflow-hidden">
                                            <div class="card-body px-4 py-5">
                                                <!-- <div class="icon-mono avatar-md bg-soft-primary text-primary rounded mx-auto mb-5"><i class="icon-lg" data-feather="circle"></i></div> -->
                                                <div class="icon-mono avatar-md bg-soft-primary rounded mx-auto mb-5 p-3">
                                                    <img src="images/pricing/1.png" alt="" class="img-fluid d-block mx-auto" />
                                                </div>
                                                <h4 class="text-uppercase mb-4 pb-1"><?php echo $award['Year'] ?></h4>
                                                <p class="font-size-16 font-weight-semibold mb-4 price-tag"><?php echo $award['Award'] ?></p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- end col -->
                                     <?php endforeach ?>
                                </div>
                                <!-- end row -->
                            </div>
                            <!-- end monthly tab pane -->

                            <div class="tab-pane fade" id="pills-yearly" role="tabpanel" aria-labelledby="pills-yearly-tab">
                                <div class="row">
                                    <div class="col-lg-4">
                                        <div class="card plan-card mt-4 rounded text-center border-0 shadow overflow-hidden">
                                            <div class="card-body px-4 py-5">
                                                <!-- <div class="icon-mono avatar-md bg-soft-primary text-primary rounded mx-auto mb-5"><i class="icon-lg" data-feather="circle"></i></div> -->
                                                <div class="icon-mono avatar-md bg-soft-primary rounded mx-auto mb-5 p-3">
                                                    <img src="images/pricing/1.png" alt="" class="img-fluid d-block mx-auto" />
                                                </div>
                                                <h4 class="text-uppercase mb-4 pb-1">Basic</h4>
                                                <p class="text-muted">Onlinespace: <span class="fw-bold">50MB</span></p>
                                                <p class="text-muted">Support: <span class="fw-bold">No</span></p>
                                                <p class="text-muted mb-4 pb-1">Domain 1</p>
                                                <p class="text-muted font-size-14 mb-1">All Extension Included</p>
                                                <p class="font-size-16 font-weight-semibold mb-4 price-tag">$29.00 / Year</p>
                                                <a href="javascript: void(0);" class="btn btn-soft-primary">Buy Now</a>
                                            </div>
                                            <!-- end cardbody -->
                                        </div>
                                        <!-- end card -->
                                    </div>
                                    <!-- end col -->
                                    <div class="col-lg-4">
                                        <div class="card plan-card mt-4 rounded text-center border-0 shadow overflow-hidden">
                                            <div class="card-body px-4 py-5">
                                                <!-- <div class="icon-mono avatar-md bg-soft-primary text-primary rounded mx-auto mb-5"><i class="icon-lg" data-feather="square"></i></div> -->
                                                <div class="icon-mono avatar-md bg-soft-primary rounded mx-auto mb-5 p-3">
                                                    <img src="images/pricing/2.png" alt="" class="img-fluid d-block mx-auto" />
                                                </div>
                                                <h4 class="text-uppercase mb-4 pb-1">Standard</h4>
                                                <p class="text-muted">Onlinespace: <span class="fw-bold">100MB</span></p>
                                                <p class="text-muted">Support: <span class="fw-bold">Yes</span></p>
                                                <p class="text-muted mb-4 pb-1">Domain 1</p>
                                                <p class="text-muted font-size-14 mb-1">All Extension Included</p>
                                                <p class="font-size-16 font-weight-semibold mb-4 price-tag">$49.00 / Year</p>
                                                <a href="javascript: void(0);" class="btn btn-soft-primary">Buy Now</a>
                                            </div>
                                            <!-- end cardbody -->
                                        </div>
                                        <!-- end card -->
                                    </div>
                                    <!-- end col -->
                                    <div class="col-lg-4">
                                        <div class="card plan-card mt-4 rounded text-center border-0 shadow overflow-hidden">
                                            <div class="card-body px-4 py-5">
                                                <span class="badge badge-primary pricing-badge shadow-lg">Most Popular</span>
                                                <!-- <div class="icon-mono avatar-md bg-soft-primary text-primary rounded mx-auto mb-5"><i class="icon-lg" data-feather="triangle"></i></div> -->
                                                <div class="icon-mono avatar-md bg-soft-primary rounded mx-auto mb-5 p-3">
                                                    <img src="images/pricing/3.png" alt="" class="img-fluid d-block mx-auto" />
                                                </div>
                                                <h4 class="text-uppercase mb-4 pb-1">Premium</h4>
                                                <p class="text-muted">Onlinespace: <span class="fw-bold">200MB</span></p>
                                                <p class="text-muted">Support: <span class="fw-bold">No</span></p>
                                                <p class="text-muted mb-4 pb-1">Domain 1</p>
                                                <p class="text-muted font-size-14 mb-1">All Extension Included</p>
                                                <p class="font-size-16 font-weight-semibold mb-4 price-tag">$99.00 / Year</p>
                                                <a href="javascript: void(0);" class="btn btn-soft-primary">Buy Now</a>
                                            </div>
                                            <!-- end cardbody -->
                                        </div>
                                        <!-- end card -->
                                    </div>
                                    <!-- end col -->
                                </div>
                            </div>
                            <!-- end yearly tab pane -->
                        </div>
                        <!-- end tab content -->
                    </div>
                    <!-- end col -->
                </div>
                <!-- end row -->
            </div>
            <!-- end container -->
        </section>
        <!-- Pricing end -->

        <!-- Team start -->
        <section class="section bg-light" id="team">
            <div class="container">
                <div class="row justify-content-center mb-4">
                    <div class="col-lg-7 text-center">
                        <h2 class="fw-bold"><?php echo "Our Team"?></h2>
                    </div>
                    <!-- end col -->
                </div>
                <?php foreach ($team as $member):?>
                <!-- end row -->
                <div class="row">
                    <div class="col-lg-3 col-sm-6">
                        <div class="team-box mt-4 position-relative overflow-hidden rounded text-center shadow">
                            <div class="position-relative overflow-hidden">
                            </div>
                            <div class="p-4">
                                <h5 class="font-size-19 mb-1"><?php echo $member['Name']; ?></h5>
                                <p class="text-muted text-uppercase font-size-14 mb-0"><?php echo $member['Position']; ?></p>
                                <p class="text-muted text-uppercase font-size-14 mb-0"><?php echo $member['Description']; ?></p>
                            </div>
                        </div>
                    </div>
                    <!-- end col -->
                </div>
                <!-- end row -->
                <?php endforeach ?>
            </div>
            <!-- end container -->
        </section>
        <!-- Team end -->

        <!-- Blog start -->
        <section class="section" id="blog">
            <div class="container">
                <div class="row justify-content-center mb-4">
                    <div class="col-lg-7 text-center">
                        <h2 class="fw-bold"><?php echo "Products" ?></h2>
                    </div>
                </div>
                <div class="row">
                <?php foreach ($products as $product): ?>
                    <div class="col-lg-4">
                        <div class="card mt-4 border-0 shadow">
                            <div class="card-body p-4">
                                <span class="badge badge-soft-primary"><?php echo $product['name']; ?></span>
                                <h4 class="font-size-22 my-4"><a href="javascript: void(0);"><?php echo $product['description']; ?></a></h4>
                                <div class="d-flex align-items-center mt-4 pt-2">
                                    <div class="flex-body">
                                        <h5 class="font-size-17 mb-0"><?php echo "Applications" ?></h5>
                                        <?php foreach ($product['applications'] as $app): ?>
                                        <p class="text-muted mb-0 font-size-14"><?php echo $app['name']; ?></p>
                                        <p class="text-muted mb-0 font-size-14"><?php echo $app['description']; ?></p>
                                        <?php endforeach ?>
                                    </div>
                                </div>
                            </div><!-- end cardbody -->
                        </div><!-- end card -->
                    </div><!-- end col -->
                    <?php endforeach ?>
                </div>
                <!-- end row -->
            </div>
            <!-- end container -->
        </section>
        <!-- Blog end -->
        <section class="section " id="contact">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <h1 class="section-title text-center">Get In Touch</h1>
                </div>
                <div class="col-lg-8">
                    <div class="custom-form mt-4 pt-4">
                        <form method="post" name="myForm" onsubmit="return validateForm()">
                            <p id="error-msg"></p>
                            <div id="simple-msg"></div>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group mt-2">
                                        <input name="name" id="name" type="text" class="form-control"
                                            placeholder="Your name*">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group mt-2">
                                        <input name="email" id="email" type="email" class="form-control"
                                            placeholder="Your email*">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form-group mt-2">
                                        <input type="text" class="form-control" id="subject"
                                            placeholder="Your Subject.." />
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form-group mt-2">
                                        <textarea name="comments" id="comments" rows="4" class="form-control"
                                            placeholder="Your message..."></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12 text-end">
                                    <input type="submit" id="submit" name="send" class="submitBnt btn btn-primary"
                                        value="Send Message">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
                        </div>
                    </div>
                    <!-- end col -->
                </div>
                <!-- end row -->
            </div>
            <!-- end container -->
        </footer>
        <!-- Footer End -->

        <!-- Style switcher -->
        <div id="style-switcher">
            <div class="bottom">
                <a href="javascript: void(0);" id="mode" class="mode-btn text-white">
                    <i class="mdi mdi-white-balance-sunny mode-light"></i>
                    <i class="mdi mdi-moon-waning-crescent mode-dark"></i>
                </a>
                <a href="javascript: void(0);" class="settings" onclick="toggleSwitcher()"><i class="mdi mdi-cog  mdi-spin"></i></a>
            </div>
        </div>

        <!-- javascript -->
        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/smooth-scroll.polyfills.min.js"></script>

        <script src="https://unpkg.com/feather-icons"></script>

        <!-- App Js -->
        <script src="js/app.js"></script>
    </body>
</html>
